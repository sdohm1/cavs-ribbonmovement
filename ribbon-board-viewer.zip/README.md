# Ribbon Board Viewer

Upload a static ribbon image and preview it scrolling left or right with adjustable speed.